library(rjags)
library(jagsUI)
library(tidyverse)
library(ggmcmc)
library(stringr)
library(MCMCvis)

#Key
#beta= Male age (rank or days)
#betaq = polynomial of age in days
#betacw = group centered weight
#betamf= Male over female sex ratio in the group
#1 - subordinate, 2 - pesterer, 3 - guard. Note for each parameter the first number refers to the previous state, and second the next state. e.g beta1[1] is how age effects the probability of staying as a subordinate.

#epsF = Female ID
#epsM = Male ID
#epsO = oestrus event ID


#Main output objects

#Model object: #NOTE The transition models only output parameter estimations for transitions from two states. Therefore, I ran an inverse model to obtain parameter estiamtes from the third state
OpmsbGid.fixedgcw.age
OpmsbGid.fixedgcw.age.inv
OpmsbGid.fixedgcw.ager
OpmsbGid.fixedgcw.ager.inv
#Significance tables fixed effects
table.OpmsbGid.fixedgcw.ager
table.OpmsbGid.fixedgcw.age
#Significance tables random effect variance
variancerand
variancerand2




compsr<-read_csv("matrixcompratio.csv")
compsr <-t(as.matrix(compsr))

code<-read_csv("matrixoestrus.codenum.csv")
code <-t(as.matrix(code))


group <-read_csv("matrixgroupnum.csv")
group <- t(as.matrix(group))



pCH1 <- read_csv("matrixstatepest.csv")
pCH <- read_csv("matrixstatepest.csv")
pCH <- t(as.matrix(pCH))

pCH[is.na(pCH)] <- 4

pCHi<-pCH
pCHi[pCHi==1]<-5#sub
pCHi[pCHi==3]<-6#guard
pCHi[pCHi==5]<-3#sub now 3
pCHi[pCHi==6]<-1#guard now 1



tableage <- read_csv("matrixage.csv")
tableage <- t(as.matrix(tableage))
meanage = mean(tableage)
sdage = sd(tableage)
recoverage <- function(x){(sdage*(x))+meanage}
standage<-function(x){(x-meanage)/sdage}
tableage <- standage(tableage)

rankage <-read_csv("matrixmale.age.rank.csv")
rankage0 <- t(round(as.matrix(rankage)))

tableage1 <- read_csv(t("matrixage.csv"))
indiv<-as.data.frame(names(tableage1))%>%rename("indiv" = "names(tableage1)")%>%mutate(num.indiv=row_number())
ind.vec <-as.matrix(indiv%>%select(num.indiv))

gcweightarchive<-as.matrix(read_csv("weightcenteredrankmatrix.csv"))
gcweightt<-as.matrix(read_csv("weightcenteredrankmatrix.csv"))
gcweight<-t(gcweightt)




initsall<- function(){list(#alpha0=runif(3, 1e-9, 1e-7),#needs to be the amount of parameters you want
  alpha1=runif(2, 1e-9, 1e-7),#needs to be the amount of parameters you want
  alpha2=runif(2, 1e-9, 1e-7),#needs to be the amount of parameters you want
  alpha3=runif(2, 1e-9, 1e-7),
  betamf1=runif(2, 1e-9, 1e-7),
  betamf2=runif(2, 1e-9, 1e-7),
  betamf3=runif(2, 1e-9, 1e-7),
  beta1=runif(2, 1e-9, 1e-7),
  beta2=runif(2, 1e-9, 1e-7),
  beta3=runif(2, 1e-9, 1e-7),
  betaq1=runif(2, 1e-9, 1e-7),
  betaq2=runif(2, 1e-9, 1e-7),
  betaq3=runif(2, 1e-9, 1e-7),
  betacw1=runif(2, 1e-9, 1e-7),
  betacw2=runif(2, 1e-9, 1e-7),
  betacw3=runif(2, 1e-9, 1e-7)
  
)}

Oparameters.all <- c(
  "alpha1", "alpha2", "alpha3", 
  "epsM1","epsM2","epsM3", 
  
  "epsO1","epsO2","epsO3", 
  "betamf1", "betamf2", "betamf3",
  "beta1", "beta2", "beta3",
  "betacw1", "betacw2", "betacw3",
  "betaq1","betaq2","betaq3",
  "epsG1", "epsG2", "epsG3")


Odataid.arwr.p<-list(n.group = length(levels(as.factor(group))), group =group,ocode = code, age = rankage0, y = pCH,  cw = gcweight,  mfrat = compsr,  
                     n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])

Oinv.dataid.arwr.p<-list(n.group = length(levels(as.factor(group))), group =group,ocode = code, age = rankage0, y = pCHi,  cw = gcweight,  mfrat = compsr,
                         n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])
Odataid.awr.p<-list(n.group = length(levels(as.factor(group))), group =group,ocode = code, age = tableage, y = pCH,  cw = gcweight,  mfrat = compsr,  
                    n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])

Oinv.dataid.awr.p<-list(n.group = length(levels(as.factor(group))), group =group,ocode = code, age = tableage, y = pCHi,  cw = gcweight,  mfrat = compsr,
                        n.code = length(levels(as.factor(code))), male=as.numeric(ind.vec), n.male = length(levels(as.factor(ind.vec))), n.occasions = dim(pCH)[2], nind = dim(pCH)[1])




sink("OmsbG.fixedar.idcwr")#b for base before looking at development
cat("
    model {
    
    # -------------------------------------------------
    # Parameters:
    # psiA B and C: movement probability from site to another   
    # M probbability of death - just intercept modelled


    # Priors and constraints
    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:3){
    logit(M[i,j,k])<- alpha0[k]

    
    
    }}} 


    
    for(i in 1:3){
    alpha0[i]~dnorm(0,0.001)
    }

    
    for(i in 1:2){
    alpha1[i]~dnorm(0,0.001)
    beta1[i]~dnorm(0,0.001)
    alpha2[i]~dnorm(0,0.001)
    beta2[i]~dnorm(0,0.001)
    alpha3[i]~dnorm(0,0.001)
    beta3[i]~dnorm(0,0.001)
    betamf1[i]~dnorm(0,0.001)#mfratio
    betacw1[i]~dnorm(0,0.001)#capture weight
    betamf2[i]~dnorm(0,0.001)#mfratio
    betacw2[i]~dnorm(0,0.001)#capture weight
    betamf3[i]~dnorm(0,0.001)#mfratio
    betacw3[i]~dnorm(0,0.001)#capture weight
    
    }
    for(i in 1:n.group){
    epsG1[i]~ dnorm(0,tau.group1) 
    epsG2[i]~ dnorm(0,tau.group2) 
    epsG3[i]~ dnorm(0,tau.group3) }
    for(i in 1:n.code){
    epsO1[i]~ dnorm(0,tau.ocode1) 
    epsO2[i]~ dnorm(0,tau.ocode2) 
    epsO3[i]~ dnorm(0,tau.ocode3)}
    
    
    for(i in 1:n.male){
    epsM1[i]~ dnorm(0,tau.male1) 
    epsM2[i]~ dnorm(0,tau.male2) 
    epsM3[i]~ dnorm(0,tau.male3)}
    
    
    
    #The sum of the transition probabilities should be equal to 1 
    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:2){    
    psia[i,j,k]<-alpha1[k]+
    beta1[k]*age[i,j]+
    betamf1[k]*mfrat[i,j]+
    betacw1[k]*cw[i,j]+#betahw1[k]*hw[i,j]+
    epsG1[group[i,j]]+
    epsM1[male[i]]+
    epsO1[ocode[i,j]]
    psib[i,j,k]<-alpha2[k]+
    beta2[k]*age[i,j]+
    betamf2[k]*mfrat[i,j]+
    betacw2[k]*cw[i,j]+#betahw2[k]*hw[i,j]+
    epsG2[group[i,j]]+
    epsM2[male[i]]+
    epsO2[ocode[i,j]]
    psic[i,j,k]<-alpha3[k]+
    beta3[k]*age[i,j]+
    betamf3[k]*mfrat[i,j]+
    betacw3[k]*cw[i,j]+#betahw3[k]*hw[i,j]+
    epsG3[group[i,j]]+
    epsM3[male[i]]+
    epsO3[ocode[i,j]]

    psiA[i,j,k] <- exp(psia[i,j,k])/(1+exp(psia[i,j,1])+exp(psia[i,j,2]))
    psiB[i,j,k] <- exp(psib[i,j,k])/(1+exp(psib[i,j,1])+exp(psib[i,j,2]))
    psiC[i,j,k] <- exp(psic[i,j,k])/(1+exp(psic[i,j,1])+exp(psic[i,j,2]))}
    psiA[i,j,3] <- 1-psiA[i,j,1]-psiA[i,j,2]
    psiB[i,j,3] <- 1-psiB[i,j,1]-psiB[i,j,2]
    psiC[i,j,3] <- 1-psiC[i,j,1]-psiC[i,j,2]}}

    

    # Define state-transition

    for (i in 1:nind){
    # Define probabilities of state S(t+1) given S(t)
    for (t in 1:(n.occasions-1)){
    ps[1,i,t,1] <- psiA[i,t,1]
    ps[1,i,t,2] <- psiA[i,t,2]
    ps[1,i,t,3] <- psiA[i,t,3]
    ps[1,i,t,4] <- M[i,t,1]
    ps[2,i,t,1] <- psiB[i,t,1]
    ps[2,i,t,2] <- psiB[i,t,2]
    ps[2,i,t,3] <- psiB[i,t,3]
    ps[2,i,t,4] <- M[i,t,2]
    ps[3,i,t,1] <- psiC[i,t,1]
    ps[3,i,t,2] <- psiC[i,t,2]
    ps[3,i,t,3] <- psiC[i,t,3]
    ps[3,i,t,4] <- M[i,t,3]
    ps[4,i,t,1] <- 0
    ps[4,i,t,2] <- 0
    ps[4,i,t,3] <- 0
    ps[4,i,t,4] <- 1
    } #t
    } #i
    
    # Likelihood 
    for (i in 1:nind){
    for (t in 2:n.occasions){
    # State process: draw S(t) given S(t-1)
    y[i,t] ~ dcat(ps[y[i,t-1], i, t-1,]) # This is a profile
    } #t
} #i
    }")
sink()



sink("OmsbG.fixedage.idcwr")#b for base before looking at development
cat("
    model {
    
    # -------------------------------------------------
    # Parameters:
    # psiA B and C: movement probability from site to another   
    # M probbability of death - just intercept modelled


    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:3){
    logit(M[i,j,k])<- alpha0[k]
    
    
    }}} 


    tau.group1 <- 1 / (sd.group1*sd.group1)
    sd.group1 ~ dunif(0, 3)
    tau.group2 <- 1 / (sd.group2*sd.group2)
    sd.group2 ~ dunif(0, 3)
    tau.group3 <- 1 / (sd.group3*sd.group3)
    sd.group3 ~ dunif(0, 3)

    tau.ocode1 <- 1 / (sd.ocode1*sd.ocode1)
    sd.ocode1 ~ dunif(0, 3)
    tau.ocode2 <- 1 / (sd.ocode2*sd.ocode2)
    sd.ocode2 ~ dunif(0, 3)
    tau.ocode3 <- 1 / (sd.ocode3*sd.ocode3)
    sd.ocode3 ~ dunif(0, 3)   
    
    
    tau.male1 <- 1 / (sd.male1*sd.male1)
    sd.male1 ~ dunif(0, 3)
    tau.male2 <- 1 / (sd.male2*sd.male2)
    sd.male2 ~ dunif(0, 3)
    tau.male3 <- 1 / (sd.male3*sd.male3)
    sd.male3 ~ dunif(0, 3) 
    
    for(i in 1:3){
    alpha0[i]~dnorm(0,0.001)
    }



    
    for(i in 1:2){
    alpha1[i]~dnorm(0,0.001)
    beta1[i]~dnorm(0,0.001)
    alpha2[i]~dnorm(0,0.001)
    beta2[i]~dnorm(0,0.001)
    alpha3[i]~dnorm(0,0.001)
    beta3[i]~dnorm(0,0.001)
    betaq1[i]~dnorm(0,0.001)
    betaq2[i]~dnorm(0,0.001)
    betaq3[i]~dnorm(0,0.001)
    betamf1[i]~dnorm(0,0.001)#mfratio
    betacw1[i]~dnorm(0,0.001)#capture weight
    betamf2[i]~dnorm(0,0.001)#mfratio
    betacw2[i]~dnorm(0,0.001)#capture weight
    betamf3[i]~dnorm(0,0.001)#mfratio
    betacw3[i]~dnorm(0,0.001)#capture weight
    
    }
    for(i in 1:n.group){
    epsG1[i]~ dnorm(0,tau.group1) 
    epsG2[i]~ dnorm(0,tau.group2) 
    epsG3[i]~ dnorm(0,tau.group3) }
    for(i in 1:n.code){
    epsO1[i]~ dnorm(0,tau.ocode1) 
    epsO2[i]~ dnorm(0,tau.ocode2) 
    epsO3[i]~ dnorm(0,tau.ocode3)}

    for(i in 1:n.male){
    epsM1[i]~ dnorm(0,tau.male1) 
    epsM2[i]~ dnorm(0,tau.male2) 
    epsM3[i]~ dnorm(0,tau.male3)}

    #The sum of the transition probabilities should be equal to 1 
    for(i in 1:nind){
    for(j in 1:n.occasions){
    for(k in 1:2){    
    psia[i,j,k]<-alpha1[k]+
    beta1[k]*age[i,j]+
    betaq1[k]*age[i,j]^2+
    betamf1[k]*mfrat[i,j]+
    betacw1[k]*cw[i,j]+#betahw1[k]*hw[i,j]+
    epsG1[group[i,j]]+
    epsM1[male[i]]+
    epsO1[ocode[i,j]]
    psib[i,j,k]<-alpha2[k]+
    beta2[k]*age[i,j]+
    betaq2[k]*age[i,j]^2+
    betamf2[k]*mfrat[i,j]+
    betacw2[k]*cw[i,j]+#betahw2[k]*hw[i,j]+
    epsG2[group[i,j]]+
    epsM2[male[i]]+
    epsO2[ocode[i,j]]
    psic[i,j,k]<-alpha3[k]+
    beta3[k]*age[i,j]+
    betaq3[k]*age[i,j]^2+
    betamf3[k]*mfrat[i,j]+
    betacw3[k]*cw[i,j]+#betahw3[k]*hw[i,j]+
    epsG3[group[i,j]]+
    epsM3[male[i]]+
    epsO3[ocode[i,j]]
    psiA[i,j,k] <- exp(psia[i,j,k])/(1+exp(psia[i,j,1])+exp(psia[i,j,2]))
    psiB[i,j,k] <- exp(psib[i,j,k])/(1+exp(psib[i,j,1])+exp(psib[i,j,2]))
    psiC[i,j,k] <- exp(psic[i,j,k])/(1+exp(psic[i,j,1])+exp(psic[i,j,2]))}
    psiA[i,j,3] <- 1-psiA[i,j,1]-psiA[i,j,2]
    psiB[i,j,3] <- 1-psiB[i,j,1]-psiB[i,j,2]
    psiC[i,j,3] <- 1-psiC[i,j,1]-psiC[i,j,2]}}
    #The sum of transition-to probabilities should be equal to 1


    # Define state-transition

    for (i in 1:nind){
    # Define probabilities of state S(t+1) given S(t)
    for (t in 1:(n.occasions-1)){
    ps[1,i,t,1] <- psiA[i,t,1]
    ps[1,i,t,2] <- psiA[i,t,2]
    ps[1,i,t,3] <- psiA[i,t,3]
    ps[1,i,t,4] <- M[i,t,1]
    ps[2,i,t,1] <- psiB[i,t,1]
    ps[2,i,t,2] <- psiB[i,t,2]
    ps[2,i,t,3] <- psiB[i,t,3]
    ps[2,i,t,4] <- M[i,t,2]
    ps[3,i,t,1] <- psiC[i,t,1]
    ps[3,i,t,2] <- psiC[i,t,2]
    ps[3,i,t,3] <- psiC[i,t,3]
    ps[3,i,t,4] <- M[i,t,3]
    ps[4,i,t,1] <- 0
    ps[4,i,t,2] <- 0
    ps[4,i,t,3] <- 0
    ps[4,i,t,4] <- 1
    } #t
    } #i
    
    # Likelihood 
    for (i in 1:nind){
    for (t in 2:n.occasions){
    # State process: draw S(t) given S(t-1)
    y[i,t] ~ dcat(ps[y[i,t-1], i, t-1,]) # This is a profile
    } #t
} #i
    }")
sink()



ni <-20000
nt <- 100
nb <-2500
nc <- 3



OpmsbGid.fixedgcw.age<- jagsUI ::jags(Odataid.awr.p, initsall, Oparameters.all, "OmsbG.fixedage.idcwr", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)
OpmsbGid.fixedgcw.age.inv<- jagsUI ::jags(Oinv.dataid.awr.p, initsall, Oparameters.all, "OmsbG.fixedage.idcwr", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)

OpmsbGid.fixedgcw.ager<- jagsUI ::jags(Odataid.arwr.p, initsall, Oparameters.all, "OmsbG.fixedar.idcwr", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)
OpmsbGid.fixedgcw.ager.inv<- jagsUI ::jags(Oinv.dataid.arwr.p, initsall, Oparameters.all, "OmsbG.fixedar.idcwr", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE)





OpmsbGid.justfixedgcw.ager.inv.corrected<-OpmsbGid.justfixedgcw.ager.inv

OpmsbGid.justfixedgcw.ager.inv.corrected$parameters<-gsub("5","1",gsub("1","3",gsub("3","5",OpmsbGid.justfixedgcw.ager.inv$parameters)))
OpmsbGid.justfixedgcw.ager.inv.corrected

ggs(OpmsbGid.justfixedgcw.ager.inv$samples)





OpmsbGid.fixedgcw.agersum<-MCMCsummary(OpmsbGid.fixedgcw.ager, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OpmsbGid.fixedgcw.agersum)
OpmsbGid.fixedgcw.ager.olap<-OpmsbGid.fixedgcw.agersum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                   low < 0 & high< 0~"-",
                                                                                   TRUE ~"NotSignif"))

write.csv(OpmsbGid.fixedgcw.ager.olap, "pmsbGid.fixedgcw.ager.olap.csv")#to make ghost name column a real column
OFpmsbGid.fixedgcw.ager.olap<-read.csv("OpmsbGid.fixedgcw.ager.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OpmsbGid.fixedgcw.ager$f)),as.data.frame(matrix(unlist(OpmsbGid.fixedgcw.ager$f ))))%>%rename("X"="names(unlist(OpmsbGid.fixedgcw.ager$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it
write.csv(OFpmsbGid.fixedgcw.ager.olap, "pmsbGid.fixedgcw.ager.olap.csv")





OpmsbGid.fixedgcw.ager.invsum<-MCMCsummary(OpmsbGid.fixedgcw.ager.inv, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OpmsbGid.fixedgcw.ager.invsum)
OpmsbGid.fixedgcw.ager.inv.olap<-OpmsbGid.fixedgcw.ager.invsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                           low < 0 & high< 0~"-",
                                                                                           TRUE ~"NotSignif"))

write.csv(OpmsbGid.fixedgcw.ager.inv.olap, "pmsbGid.fixedgcw.ager.inv.olap.csv")
OFpmsbGid.fixedgcw.ager.inv.olap<-read.csv("OpmsbGid.fixedgcw.ager.inv.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OpmsbGid.fixedgcw.ager.inv$f)),as.data.frame(matrix(unlist(OpmsbGid.fixedgcw.ager.inv$f ))))%>%rename("X"="names(unlist(OpmsbGid.fixedgcw.ager.inv$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it
write.csv(OFpmsbGid.fixedgcw.ager.inv.olap, "pmsbGid.fixedgcw.ager.inv.olap.csv")

OFpmsbGid.fixedgcw.ager.inv.olap<-OFpmsbGid.fixedgcw.ager.inv.olap%>%mutate(X = gsub("3","5",X), X=gsub("1","3",X), X=gsub("5","1",X))#this was kinda easy to sub in the right numbers
invkeep<-OFpmsbGid.fixedgcw.ager.inv.olap%>%anti_join(OFpmsbGid.fixedgcw.ager.olap, by=c("X"))#all these we want to keep!
table.OpmsbGid.fixedgcw.ager<-rbind(OFpmsbGid.fixedgcw.ager.olap,invkeep)%>%arrange(as.character(X))



OpmsbGid.fixedgcw.agesum<-MCMCsummary(OpmsbGid.fixedgcw.age, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OpmsbGid.fixedgcw.agesum)
OpmsbGid.fixedgcw.age.olap<-OpmsbGid.fixedgcw.agesum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                 low < 0 & high< 0~"-",
                                                                                 TRUE ~"NotSignif"))

write.csv(OpmsbGid.fixedgcw.age.olap, "pmsbGid.fixedgcw.age.olap.csv")#to make ghost name column a real column
OFpmsbGid.fixedgcw.age.olap<-read.csv("OpmsbGid.fixedgcw.age.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OpmsbGid.fixedgcw.age$f)),as.data.frame(matrix(unlist(OpmsbGid.fixedgcw.age$f ))))%>%rename("X"="names(unlist(OpmsbGid.fixedgcw.age$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it
write.csv(OFpmsbGid.fixedgcw.age.olap, "pmsbGid.fixedgcw.age.olap.csv")





OpmsbGid.fixedgcw.age.invsum<-MCMCsummary(OpmsbGid.fixedgcw.age.inv, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(OpmsbGid.fixedgcw.age.invsum)
OpmsbGid.fixedgcw.age.inv.olap<-OpmsbGid.fixedgcw.age.invsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                         low < 0 & high< 0~"-",
                                                                                         TRUE ~"NotSignif"))

write.csv(OpmsbGid.fixedgcw.age.inv.olap, "pmsbGid.fixedgcw.age.inv.olap.csv")
OFpmsbGid.fixedgcw.age.inv.olap<-read.csv("OpmsbGid.fixedgcw.age.inv.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(OpmsbGid.fixedgcw.age.inv$f)),as.data.frame(matrix(unlist(OpmsbGid.fixedgcw.age.inv$f ))))%>%rename("X"="names(unlist(OpmsbGid.fixedgcw.age.inv$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it
write.csv(OFpmsbGid.fixedgcw.age.inv.olap, "pmsbGid.fixedgcw.age.inv.olap.csv")

OFpmsbGid.fixedgcw.age.inv.olap<-OFpmsbGid.fixedgcw.age.inv.olap%>%mutate(X = gsub("3","5",X), X=gsub("1","3",X), X=gsub("5","1",X))#this was kinda easy to sub in the right numbers
invkeep<-OFpmsbGid.fixedgcw.age.inv.olap%>%anti_join(OFpmsbGid.fixedgcw.age.olap, by=c("X"))#all these we want to keep!
table.OpmsbGid.fixedgcw.age<-rbind(OFpmsbGid.fixedgcw.age.olap,invkeep)%>%arrange(as.character(X))



variancerand<-ggs(OpmsbGid.fixedgcw.ager$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()
variancerand2<-ggs(OpmsbGid.fixedgcw.age$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()















#Extracting outputs to make significance and diagnostic plots.
#Note - outputs assocaited with transitions to guarding roles are added from a seperate inverse models. When constraining 3 probabilities to add up to one, we could not find a way to monitor all 3 probabilities in one model hence the inverse model. 

ggstate<-ggs(OpmsbGid.fixedgcw.age$samples)
ggstateinv<-ggs(OpmsbGid.fixedgcw.age.inv$samples)


ggstaterand<-ggstate%>%filter(str_detect(Parameter, 'eps'))#making seperate random dataframe and filtering fixed
ggstate<-filter(ggstate, !grepl('eps', Parameter))
ggstateinv<-filter(ggstateinv, !grepl('eps', Parameter))
ggstate$Parameter<-str_replace_all(ggstate$Parameter,"\\[|\\]", "")%>%#renaming parameters to join inverse
  str_replace("11", "Sub.to.sub")%>%
  str_replace("12", "Sub.to.pest")%>%
  str_replace("22", "Pest.to.pest")%>%
  str_replace("21", "Pest.to.sub")%>%
  str_replace("31", "Guard.to.sub")%>%
  str_replace("32", "Guard.to.pest")


ggstateinv$Parameter<-str_replace_all(ggstateinv$Parameter,"\\[|\\]", "")%>%#renaming parameters to join inverse
  str_replace("11", "Guard.to.guard")%>%
  str_replace("21", "Pest.to.guard")%>%
  str_replace("31", "Sub.to.guard")

ggstateinv2<-ggstateinv%>%
  filter(str_detect(Parameter, 'guard'))
#joining fixed so sub/pest/guard combined!


ggstategcwaint<-rbind(ggstate,ggstateinv2)%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('deviance', Parameter))


ggstate<-ggs(OpmsbGid.fixedgcw.ager$samples)
ggstateinv<-ggs(OpmsbGid.fixedgcw.ager.inv$samples)


ggstaterand<-ggstate%>%filter(str_detect(Parameter, 'eps'))#making seperate random dataframe and filtering fixed
ggstate<-filter(ggstate, !grepl('eps', Parameter))
ggstateb<-ggstate
ggstateinv<-filter(ggstateinv, !grepl('eps', Parameter))
ggstateinvb<-ggstateinv
ggstate$Parameter<-str_replace_all(ggstate$Parameter,"\\[|\\]", "")%>%#renaming parameters to join inverse
  str_replace("11", "Sub.to.sub")%>%
  str_replace("12", "Sub.to.pest")%>%
  str_replace("22", "Pest.to.pest")%>%
  str_replace("21", "Pest.to.sub")%>%
  str_replace("31", "Guard.to.sub")%>%
  str_replace("32", "Guard.to.pest")


ggstateinv$Parameter<-str_replace_all(ggstateinv$Parameter,"\\[|\\]", "")%>%#renaming parameters to join inverse
  str_replace("11", "Guard.to.guard")%>%
  str_replace("21", "Pest.to.guard")%>%
  str_replace("31", "Sub.to.guard")

ggstateinv2<-ggstateinv%>%
  filter(str_detect(Parameter, 'guard'))
#joining fixed so sub/pest/guard combined!




ggstategcwarint<-rbind(ggstate,ggstateinv2)%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('deviance', Parameter))

ggstategcwarint$Parameter<-str_replace_all(ggstategcwarint$Parameter,"\\[|\\]", "")%>%
  str_replace("betaSub", "Age.rankSub")%>%
  str_replace("betaGuard", "Age.rankGuard")%>%
  str_replace("betaPest", "Age.rankPest")%>%
  str_replace("Sub.to.sub","[Stay.sub]")%>%
  str_replace("Sub.to.pest","[Sub.to.pest]")%>%
  str_replace("Pest.to.pest","[Stay.pest]")%>%
  str_replace("Pest.to.sub","[Pest.to.sub]")%>%
  str_replace("Guard.to.sub","[Guard.to.sub]")%>%
  str_replace("Guard.to.pest","[Guard.to.pest]")%>%
  str_replace("Guard.to.guard","[Stay.guard]")%>%
  str_replace("Pest.to.guard","[Pest.to.guard]")%>%
  str_replace("Sub.to.guard","[Sub.to.guard]")%>%
  str_replace("betamf","GroupSexRatio")%>%
  str_replace("betacw","GroupCenteredWeight(g)")


ggstategcwaint$Parameter<-str_replace_all(ggstategcwaint$Parameter,"\\[|\\]", "")%>%
  str_replace("betaSub", "Age(days)Sub")%>%
  str_replace("betaGuard", "Age(days)Guard")%>%
  str_replace("betaPest", "Age(days)Pest")%>%
  str_replace("Sub.to.sub","[Stay.sub]")%>%
  str_replace("Sub.to.pest","[Sub.to.pest]")%>%
  str_replace("Pest.to.pest","[Stay.pest]")%>%
  str_replace("Pest.to.sub","[Pest.to.sub]")%>%
  str_replace("Guard.to.sub","[Guard.to.sub]")%>%
  str_replace("Guard.to.pest","[Guard.to.pest]")%>%
  str_replace("Guard.to.guard","[Stay.guard]")%>%
  str_replace("Pest.to.guard","[Pest.to.guard]")%>%
  str_replace("Sub.to.guard","[Sub.to.guard]")%>%
  str_replace("betamf","GroupSexRatio")%>%
  str_replace("betaq","Age^2(days)")%>%
  str_replace("betacw","GroupCenteredWeight(g)")



ordergcwar <- c(   "Age.rank[Stay.sub]"          ,"Age.rank[Sub.to.pest]"     ,"Age.rank[Sub.to.guard]"   ,
                   "Age.rank[Pest.to.sub]"   ,"Age.rank[Stay.pest]"           , "Age.rank[Pest.to.guard]"    ,
                   "Age.rank[Guard.to.sub]" ,"Age.rank[Guard.to.pest]", "Age.rank[Stay.guard]"  ,
                   "GroupCenteredWeight(g)[Stay.sub]"          ,"GroupCenteredWeight(g)[Sub.to.pest]"      , "GroupCenteredWeight(g)[Sub.to.guard]" ,
                   "GroupCenteredWeight(g)[Pest.to.sub]"       ,"GroupCenteredWeight(g)[Stay.pest]"        ,"GroupCenteredWeight(g)[Pest.to.guard]"  ,   
                   "GroupCenteredWeight(g)[Guard.to.sub]"     , "GroupCenteredWeight(g)[Guard.to.pest]"    ,"GroupCenteredWeight(g)[Stay.guard]"     ,   
                   "GroupSexRatio[Stay.sub]"     , "GroupSexRatio[Sub.to.pest]"  ,"GroupSexRatio[Sub.to.guard]",
                   "GroupSexRatio[Pest.to.sub]"  , "GroupSexRatio[Stay.pest]"    , "GroupSexRatio[Pest.to.guard]" ,
                   "GroupSexRatio[Guard.to.sub]" , "GroupSexRatio[Guard.to.pest]",   "GroupSexRatio[Stay.guard]"  )


ordercwage <- c( "Age(days)[Stay.sub]"          ,"Age^2(days)[Stay.sub]"       ,"Age(days)[Sub.to.pest]"     ,"Age^2(days)[Sub.to.pest]"    ,"Age(days)[Sub.to.guard]"   ,"Age^2(days)[Sub.to.guard]" ,
                 "Age(days)[Pest.to.sub]"   ,"Age^2(days)[Pest.to.sub]"    ,"Age(days)[Stay.pest]"           , "Age^2(days)[Stay.pest]"       , "Age(days)[Pest.to.guard]"    ,   "Age^2(days)[Pest.to.guard]" , 
                 "Age(days)[Guard.to.sub]" , "Age^2(days)[Guard.to.sub]"   , "Age(days)[Guard.to.pest]","Age^2(days)[Guard.to.pest]" , "Age(days)[Stay.guard]"  , "Age^2(days)[Stay.guard]"  ,   
                 
                 "GroupCenteredWeight(g)[Stay.sub]"          ,"GroupCenteredWeight(g)[Sub.to.pest]"      , "GroupCenteredWeight(g)[Sub.to.guard]" ,
                 "GroupCenteredWeight(g)[Pest.to.sub]"       ,"GroupCenteredWeight(g)[Stay.pest]"        ,"GroupCenteredWeight(g)[Pest.to.guard]"  ,   
                 "GroupCenteredWeight(g)[Guard.to.sub]"     , "GroupCenteredWeight(g)[Guard.to.pest]"    ,"GroupCenteredWeight(g)[Stay.guard]"     ,   
                 "GroupSexRatio[Stay.sub]"     , "GroupSexRatio[Sub.to.pest]"  ,"GroupSexRatio[Sub.to.guard]",
                 "GroupSexRatio[Pest.to.sub]"  , "GroupSexRatio[Stay.pest]"    , "GroupSexRatio[Pest.to.guard]" ,
                 "GroupSexRatio[Guard.to.sub]" , "GroupSexRatio[Guard.to.pest]",   "GroupSexRatio[Stay.guard]"   )

orderall <- c(   "Age.rank[Stay.sub]"          ,"Age.rank[Sub.to.pest]"     ,"Age.rank[Sub.to.guard]"   ,
                 "Age.rank[Pest.to.sub]"   ,"Age.rank[Stay.pest]"           , "Age.rank[Pest.to.guard]"    ,
                 "Age.rank[Guard.to.sub]" ,"Age.rank[Guard.to.pest]", "Age.rank[Stay.guard]"  ,
                 "Age(days)[Stay.sub]"          ,"Age^2(days)[Stay.sub]"       ,"Age(days)[Sub.to.pest]"     ,"Age^2(days)[Sub.to.pest]"    ,"Age(days)[Sub.to.guard]"   ,"Age^2(days)[Sub.to.guard]" ,
                 "Age(days)[Pest.to.sub]"   ,"Age^2(days)[Pest.to.sub]"    ,"Age(days)[Stay.pest]"           , "Age^2(days)[Stay.pest]"       , "Age(days)[Pest.to.guard]"    ,   "Age^2(days)[Pest.to.guard]" , 
                 "Age(days)[Guard.to.sub]" , "Age^2(days)[Guard.to.sub]"   , "Age(days)[Guard.to.pest]","Age^2(days)[Guard.to.pest]" , "Age(days)[Stay.guard]"  , "Age^2(days)[Stay.guard]"  ,   
                 "GroupCenteredWeight(g)[Stay.sub]"          ,"GroupCenteredWeight(g)[Sub.to.pest]"      , "GroupCenteredWeight(g)[Sub.to.guard]" ,
                 "GroupCenteredWeight(g)[Pest.to.sub]"       ,"GroupCenteredWeight(g)[Stay.pest]"        ,"GroupCenteredWeight(g)[Pest.to.guard]"  ,   
                 "GroupCenteredWeight(g)[Guard.to.sub]"     , "GroupCenteredWeight(g)[Guard.to.pest]"    ,"GroupCenteredWeight(g)[Stay.guard]"     ,   
                 "GroupSexRatio[Stay.sub]"     , "GroupSexRatio[Sub.to.pest]"  ,"GroupSexRatio[Sub.to.guard]",
                 "GroupSexRatio[Pest.to.sub]"  , "GroupSexRatio[Stay.pest]"    , "GroupSexRatio[Pest.to.guard]" ,
                 "GroupSexRatio[Guard.to.sub]" , "GroupSexRatio[Guard.to.pest]",   "GroupSexRatio[Stay.guard]"  )


ggstateall<-rbind(ggstategcwarint%>%filter(!grepl('Sex', Parameter)),ggstategcwaint%>%filter(!grepl('Weight', Parameter)))
unique(ggstateall$Parameter)

ggstateall$Parameter<-factor(ggstateall$Parameter, levels=orderall)




catsubpestguardstateall<-ggs_caterpillar(ggstateall%>%na.omit(), line=0, sort=FALSE)+ theme_classic()+ xlim(-1.75,1.75)+
  labs(x="Posterior transition probability (HPD)", y="Parameter")+
  scale_y_discrete(limits=rev)


ggs_density(ggstateall%>%filter(grepl('Age', Parameter)), hpd=TRUE)+xlim(-1.75,1.75)+ geom_vline(xintercept = 0)+theme_classic()+labs(y="Posteior samples")
ggs_density(ggstateall%>%filter(grepl('Group', Parameter)), hpd=TRUE)+xlim(-1.75,1.75)+ geom_vline(xintercept = 0)+theme_classic()+labs(y="Posteior samples")

ggs_compare_partial(ggstateall%>%filter(grepl('Age.rank', Parameter)))#compares whole chain with the last value
ggs_autocorrelation(ggstateall%>%filter(grepl('Age.rank', Parameter)))
ggs_traceplot(ggstateall%>%filter(grepl('Age.rank', Parameter)))#traceplot of convergence
ggs_compare_partial(ggstateall%>%filter(grepl('days', Parameter)))#compares whole chain with the last value
ggs_autocorrelation(ggstateall%>%filter(grepl('days', Parameter)))
ggs_traceplot(ggstateall%>%filter(grepl('days', Parameter)))#traceplot of convergence
ggs_compare_partial(ggstateall%>%filter(grepl('Centered', Parameter)))#compares whole chain with the last value
ggs_autocorrelation(ggstateall%>%filter(grepl('Centered', Parameter)))
ggs_traceplot(ggstateall%>%filter(grepl('Centered', Parameter)))#traceplot of convergence
ggs_compare_partial(ggstateall%>%filter(grepl('SexRatio', Parameter)))#compares whole chain with the last value
ggs_autocorrelation(ggstateall%>%filter(grepl('SexRatio', Parameter)))
ggs_traceplot(ggstateall%>%filter(grepl('SexRatio', Parameter)))#traceplot of convergence


ggs_crosscorrelation(ggstateall%>%filter(grepl('Stay.guard', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstateall%>%filter(grepl('Stay.pest', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstateall%>%filter(grepl('Stay.sub', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstateall%>%filter(grepl('Pest.to.sub', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstateall%>%filter(grepl('Pest.to.guard', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstateall%>%filter(grepl('Guard.to.sub', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstateall%>%filter(grepl('Guard.to.pest', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstateall%>%filter(grepl('Sub.to.pest', Parameter)))#check for highly correlated dependent variables (deep blue or red)
ggs_crosscorrelation(ggstateall%>%filter(grepl('Sub.to.guard', Parameter)))#check for highly correlated dependent variables (deep blue or red)
