#Key
#betasuit=number of competitors after the same female
#betastate = Behavioural strategy (Guard vs Pestering)
#betacindex = Proportion of competitors using the same strategy going after the same female
#epsF = Female ID
#epsM = Male ID
#epsO = oestrus event ID


#Main output objects

#Model object
msfit0.sigPG.juststatesuitnegfreq
#Significance tables fixed effects
table.msfit0.sigPG.juststatesuitnegfreq
#Significance tables random effect variance
variancenegfreqfit

table.msfit0.sigPG.juststatesuitnegfreq


library(rjags)
library(jagsUI)
library(tidyverse)
library(ggmcmc)
library(stringr)
library(MCMCvis)
inits0 <- function(){list(alpha=runif(1),#needs to be the amount of parameters you want
                          betasuit=runif(1),
                          betastate=runif(1),
                          betacindex=runif(1)
)}

parameters0.sig <- c(#"M",
  #  "psiA","psiB","psiC", 
  "alpha","betasuit","betastate", "betacindex"#,"betafrage", "inta.mfrage"
  ,"epsF", "epsM", "epsO", "epsG", "WAIC"
)

fertile.interact.average.comp.finPG<-read_csv("fitness.ARTs.data.csv")

#standardising functions

meansuit=mean(fertile.interact.average.comp.finPG$n_suitors_SDOB)
sdsuit = sd(fertile.interact.average.comp.finPG$n_suitors_SDOB)
recoversuit <- function(x){(sdsuit*(x))+meansuit}
standsuit<-function(x){(x-meansuit)/sdsuit}



jags.data.fit0PG.negfreq <- list( y = fertile.interact.average.comp.finPG$diad.success.binom,n = length(fertile.interact.average.comp.finPG$diad.success.binom),
                                  suit = standsuit(fertile.interact.average.comp.finPG$n_suitors),
                                  cindex=fertile.interact.average.comp.finPG$propstrat,
                                  state=fertile.interact.average.comp.finPG$staten,
                                  code = fertile.interact.average.comp.finPG$coden,
                                  male = fertile.interact.average.comp.finPG$malen,
                                  fem = fertile.interact.average.comp.finPG$femn,
                                  codel= length(levels(as.factor(round(fertile.interact.average.comp.finPG$coden)))),
                                  malel= length(levels(as.factor(round(fertile.interact.average.comp.finPG$malen)))),
                                  feml= length(levels(as.factor(round(fertile.interact.average.comp.finPG$femn)))))


ni <-100000
nt <- 100
nb <-10000
nc <- 3


sink("diad.fit.model0.juststatesuit.sigma.negfreq")
cat("
model {
for (i in 1:n){
y[i] ~ dbern(p[i])
logit(p[i]) <- max(-20,min(20,z[i]))#constraining
z[i] <- alpha
+betasuit*suit[i]
+betastate*state[i]
+betacindex*cindex[i]
+epsF[fem[i]]
+epsM[male[i]]
+epsO[code[i]]
}
alpha ~ dnorm(0, .001)
betasuit ~ dnorm(0, .001)
betastate ~ dnorm(0, .001)
betacindex~ dnorm(0, .001)



tau.oc <- 1 / (sd.oc*sd.oc)
sd.oc ~ dunif(0, 1)
tau.m <- 1 / (sd.m*sd.m)
sd.m ~ dunif(0, 1)
tau.f <- 1 / (sd.f*sd.f)
sd.f ~ dunif(0, 1)


for(i in 1:codel){
epsO[i]~ dnorm(0,tau.oc)}
for(i in 1:malel){
epsM[i]~ dnorm(0,tau.m)}
for(i in 1:feml){
epsF[i]~ dnorm(0,tau.f)}
}
")
sink()






msfit0.sigPG.juststatesuitnegfreq<-jagsUI ::jags(jags.data.fit0PG.negfreq, inits0, parameters0.sig, "diad.fit.model0.juststatesuit.sigma.negfreq", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE,DIC=T)#Beh?


msfit0.sigPG.juststatesuitnegfreqsum<-MCMCsummary(msfit0.sigPG.juststatesuitnegfreq, round = 2)%>%rename(low = "2.5%", high = "97.5%")
names(ms1sum)
msfit0.sigPG.juststatesuitnegfreqsum.olap<-msfit0.sigPG.juststatesuitnegfreqsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                                            low < 0 & high< 0~"-",
                                                                                                            TRUE ~"NotSignif"))


str(Omsb.id.WR.age.olap)
write.csv(msfit0.sigPG.juststatesuitnegfreqsum.olap, "Omsfit0.sigPG.juststatesuitnegfreqsum.olap.csv")#to make ghost name column a real column
table.msfit0.sigPG.juststatesuitnegfreq<-read.csv("Omsfit0.sigPG.juststatesuitnegfreqsum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(msfit0.sigPG.juststatesuitnegfreq$f)),as.data.frame(matrix(unlist(msfit0.sigPG.juststatesuitnegfreq$f ))))%>%rename("X"="names(unlist(msfit0.sigPG.juststatesuitnegfreq$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it

table.msfit0.sigPG.juststatesuitnegfreq

variancenegfreqfit<-ggs(msfit0.sigPG.juststatesuitnegfreq$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsF", Parameter)~"Female.id",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()



variancenegfreqfit






ggmsfit0.sigPG.juststatesuitnegfreq<-ggs(msfit0.sigPG.juststatesuitnegfreq$samples)
ggs_traceplot(ggmsfit0.sigPG.juststatesuitnegfreq%>%filter(grepl('beta', Parameter)))
ggs_traceplot(ggmsfit0.sigPG.juststatesuitnegfreq%>%filter(grepl('inta', Parameter)))
ggmsfit0.sigPG.juststatesuitnegfreq<-ggs(msfit0.sigPG.juststatesuitnegfreq$samples)%>%mutate(From=case_when(grepl('1', Parameter) ~ "Subordinate",
                                                                  grepl('2', Parameter) ~ "Pesterer",
                                                                  grepl('3', Parameter) ~ "Guard"))%>% mutate(Parameter2=Parameter)%>%
  mutate(Parameter2 = gsub("\\[|.]","",Parameter2))%>% mutate(Parameter2 = gsub("0","",Parameter2))%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('eps', Parameter))%>%mutate(Parameter=case_when(
    Parameter=="betacindex" ~    "Competitors(shared tactic)",
    Parameter=="betastate"   ~"ReproductiveState",
    Parameter=="betasuit"   ~"Competitors(n)",
  ))%>%arrange(desc(Parameter))%>%drop_na(Parameter)

unique(ggmsfit0.sigPG$Parameter)





#significance and diagnostic plots
catallsigniffixed<-ggs_caterpillar(ggmsfit0.sigPG.juststatesuitnegfreq%>%drop_na(Parameter)%>%filter(!grepl('deviance', Parameter)), line=0, sort=FALSE)+ theme_classic()+ xlim(-7.5,7.5)+
  labs(x="Posterior probability (HPD) for siring offspring from female", y="Parameter")

ggs_density(ggmsfit0.sigPG.juststatesuitnegfreq, hpd=TRUE)+xlim(-2,2)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggmsfit0.sigPG.juststatesuitnegfreq)#compares whole chain with the last value
ggs_autocorrelation(ggmsfit0.sigPG.juststatesuitnegfreq)
ggs_traceplot(ggmsfit0.sigPG.juststatesuitnegfreq)#traceplot of convergence
ggs_crosscorrelation(ggmsfit0.sigPG.juststatesuitnegfreq)#check for highly correlated dependent variables (deep blue or red)
