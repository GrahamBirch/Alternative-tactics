library(rjags)
library(jagsUI)
library(tidyverse)
library(ggmcmc)
library(stringr)
library(MCMCvis)

#Key
#bstate= Behavioural state
#epsG = Group ID
#epsM = Male ID
#epsO = oestrus event ID



#Main output objects

#Model object
ms.weightdif10.pcw.state
#Significance tables fixed effects
fit.table.ms.weightdif10.pcw.state
#Significance tables random effect variance
variancerand


#organising data and specifying model
weightdifsdf10<-read_csv("weightlossdate.csv")


sd1<-sd(weightdifsdf10$agerank,na.rm=TRUE)
mean1<-mean(weightdifsdf10$agerank,na.rm=TRUE)
recoveragerank <- function(x){(sd1*(x))+mean1}
standagerank <-function(x){(x-mean1)/sd1}

sd2<-sd(weightdifsdf10$age,na.rm=TRUE)
mean2<-mean(weightdifsdf10$age,na.rm=TRUE)
recoverage <- function(x){(sd2*(x))+mean2}
standage <-function(x){(x-mean2)/sd2}

sd3<-sd(weightdifsdf10$timea,na.rm=TRUE)
mean3<-mean(weightdifsdf10$timea,na.rm=TRUE)
recovertimea <- function(x){(sd3*(x))+mean3}
standtimea <-function(x){(x-mean3)/sd3}


sd4<-sd(weightdifsdf10$length,na.rm=TRUE)
mean4<-mean(weightdifsdf10$length,na.rm=TRUE)
recoverlength <- function(x){(sd4*(x))+mean4}
standlength <-function(x){(x-mean4)/sd4}

sd5<-sd(weightdifsdf10$mfratio,na.rm=TRUE)
mean5<-mean(weightdifsdf10$mfratio,na.rm=TRUE)
recovermfratio <- function(x){(sd5*(x))+mean5}
standmfratio <-function(x){(x-mean5)/sd5}

sd7<-sd(weightdifsdf10$weightb,na.rm=TRUE)
mean7<-mean(weightdifsdf10$weightb,na.rm=TRUE)
recoverweightb <- function(x){(sd7*(x))+mean7}
standweightb <-function(x){(x-mean7)/sd7}

weightdifsdf10.pcw<-weightdifsdf10.pcw%>%mutate(malen=as.numeric(as.factor(indiv)))
jags.data.weightdif10.pcw<- list( y = (
  weightdifsdf10.pcw$weightdif),n = length(weightdifsdf10.pcw$weightdif),
  ar=standagerank(weightdifsdf10.pcw$agerank),
  age=standage(weightdifsdf10.pcw$age),
  timea=standtimea(weightdifsdf10.pcw$timea),
  leng=standlength(weightdifsdf10.pcw$length),
  mf=standmfratio(weightdifsdf10.pcw$mfratio),
  cw=standweightb(weightdifsdf10.pcw$weightb),
  staten= (weightdifsdf10.pcw$staten),
  code = weightdifsdf10.pcw$coden,
  group = weightdifsdf10.pcw$groupn,
  male = weightdifsdf10.pcw$malen,
  malel= length(levels(as.factor(round(weightdifsdf10.pcw$malen)))),
  codel= length(levels(as.factor(round(weightdifsdf10.pcw$coden)))),
  statel= length(levels(as.factor(round(weightdifsdf10.pcw$staten)))),
  groupl= length(levels(as.factor(round(weightdifsdf10.pcw$groupn)))))

parameters.wdif <- c(#"M",
  #  "psiA","psiB","psiC", 
  "alpha","bState","epsM",
  "epsO"
  , "epsG"#, "epsO", "WAIC"
)

inits.wdif <- function(){list(alpha=runif(1)
)}




sink("weightdif.mod.statet")
cat(" 
  model{ 
    # likelihood
    for (i in 1:n){
            y[i] ~ dnorm(mu[i], tau)
            mu[i] <- alpha 
            +epsG[group[i]]
            +epsO[code[i]]
            +epsM[male[i]]
                        +bState[staten[i]] 
                        
    }
    # priors
alpha ~ dnorm(0, .001)


	sigma ~ dunif(0, 100) # standard deviation
	tau <- 1 / (sigma * sigma) # sigma^2 doesn't work in JAGS

for(i in 1:3) {
    temp[i] ~ dnorm(0, 0.001)}#so compare to 0
bState<- temp - mean(temp)

tau.oc <- 1 / (sd.oc*sd.oc)
sd.oc ~ dunif(0, 1)
tau.g <- 1 / (sd.g*sd.g)
sd.g ~ dunif(0, 1)
tau.m <- 1 / (sd.m*sd.m)
sd.m ~ dunif(0, 1)

for(i in 1:codel){
epsO[i]~ dnorm(0,tau.oc)}
for(i in 1:groupl){
epsG[i]~ dnorm(0,tau.g)}
for(i in 1:malel){
epsM[i]~ dnorm(0,tau.m)}}")
sink()


ni <-50000
nt <- 100
nb <-5000
nc <- 3

ms.weightdif10.pcw.state<-jagsUI::jags(jags.data.weightdif10.pcw, inits.wdif, parameters.wdif, "weightdif.mod.statet", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE,DIC=T)#Beh?



#Constructing output table

ms.weightdif10.pcw.statesum<-MCMCsummary(ms.weightdif10.pcw.state, round = 2)%>%rename(low = "2.5%", high = "97.5%")

names(ms1sum)
ms.weightdif10.pcw.statesum.olap<-ms.weightdif10.pcw.statesum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                          low < 0 & high< 0~"-",
                                                                                          TRUE ~"NotSignif"))



write.csv(ms.weightdif10.pcw.statesum.olap, "Oms.weightdif10.pcw.statesum.olap.csv")#to make ghost name column a real column
fit.table.ms.weightdif10.pcw.state<-read.csv("Oms.weightdif10.pcw.statesum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(ms.weightdif10.pcw.state$f)),as.data.frame(matrix(unlist(ms.weightdif10.pcw.state$f ))))%>%rename("X"="names(unlist(ms.weightdif10.pcw.state$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it


variancerand<-ggs(ms.weightdif10.pcw.state$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsG", Parameter)~"Group",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()






ggms.weightdif10.pcw.state<-ggs(ms.weightdif10.pcw.state$samples)
ggms.weightdif10.pcw.state<-ggms.weightdif10.pcw.state%>%filter(!grepl('alpha', Parameter))%>%filter(!grepl('deviance', Parameter))%>%filter(!grepl('eps', Parameter))%>%arrange(Parameter)#making seperate random dataframe and filtering fixed

ggms.weightdif10.pcw.state<-ggs(ms.weightdif10.pcw.state$samples)%>%mutate(Parameter=case_when(
  Parameter=="bState[1]" ~"Subordinate",
  Parameter=="bState[2]"  ~"Pesterer",#cindex not informative as if competing with guard will be on a seperate day
  Parameter=="bState[3]"   ~"Guarder"
))%>%arrange(desc(Parameter))%>%na.omit()


4+4
catwlos2<-ggs_caterpillar(ggms.weightdif10.pcw.state%>%drop_na(Parameter), line=0, sort=FALSE)+ theme_classic()+ xlim(-2,2)+
  labs(x="Posterior probability (HPD) for weight change (% of bodyweight)", y="")+scale_y_discrete(limits=rev)


#Significance plots and model diagnostics

ggs_density(ggms.weightdif10.pcw.state, hpd=TRUE)+xlim(-2,2)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggms.weightdif10.pcw.state)#compares whole chain with the last value
ggs_autocorrelation(ggms.weightdif10.pcw.state)
ggs_traceplot(ggms.weightdif10.pcw.state)#traceplot of convergence
ggs_crosscorrelation(ggms.weightdif10.pcw.state)#check for highly correlated dependent variables (deep blue or red)

