library(rjags)
library(jagsUI)
library(tidyverse)
library(ggmcmc)
library(stringr)
library(MCMCvis)

#Key
#betafa= Female age rank
#betama = male age rank
#betar= relatedness
#betapg = Reproductive state (Guard vs pesterer)
#betanfem = number of females
#intafmapg = Interaction between female age rank, male age rank and reproductive state.
#intafapg, intamapg, intafma = two way interactions
#epsF = Female ID
#epsM = Male ID
#epsO = oestrus event ID


#Main output objects

#Model object
msfit0.sigPG.juststatesuitnegfreq
#Significance tables fixed effects
fit.table.actint.PG.model.intfmapg.intafac.intamac.r.nfem
#Significance tables random effect variance
variancerand


#Specifying the model

mfcomborelonlydaysinteract<-read_csv("mate choice data.csv")

meanM.F.Ratio.event=mean(mfcomborelonlydaysinteract$M.F.Ratio.event)
sdM.F.Ratio.event = sd(mfcomborelonlydaysinteract$M.F.Ratio.event)
recoverM.F.Ratio.event4 <- function(x){(sdM.F.Ratio.event*(x))+meanM.F.Ratio.event}
standM.F.Ratio.event4<-function(x){(x-meanM.F.Ratio.event)/sdM.F.Ratio.event}

meansessionn=mean(mfcomborelonlydaysinteract$sessionn)
sdsessionn = sd(mfcomborelonlydaysinteract$sessionn)
recoversessionn4 <- function(x){(sdsessionn*(x))+meansessionn}
standsessionn4<-function(x){(x-meansessionn)/sdsessionn}

meanfagerank=mean(mfcomborelonlydaysinteract$fagerank)
sdfagerank = sd(mfcomborelonlydaysinteract$fagerank)
recoverfagerank4 <- function(x){(sdfagerank*(x))+meanfagerank}
standfagerank4<-function(x){(x-meanfagerank)/sdfagerank}

meanmale.age.rank=mean(mfcomborelonlydaysinteract$male.age.rank)
sdmale.age.rank = sd(mfcomborelonlydaysinteract$male.age.rank)
recovermale.age.rank4 <- function(x){(sdmale.age.rank*(x))+meanmale.age.rank}
standmale.age.rank4<-function(x){(x-meanmale.age.rank)/sdmale.age.rank}


initsA<- function(){list(alpha=runif(1),
                         betafa=runif(1), betama=runif(1), betar=runif(1), betapg=runif(1), betanfem=runif(1), intafma=runif(1), intafapg=runif(1), intamapg=runif(1), intafmapg=runif(1)
)}

jags.data.A.int<- list( y = mfcomborelonlydaysinteract$diad.interactn ,n = length(mfcomborelonlydaysinteract$diad.interactn),
                        fage=standfagerank4(mfcomborelonlydaysinteract$fagerank), mage=standmale.age.rank4(mfcomborelonlydaysinteract$male.age.rank),comp=standM.F.Ratio.event4(mfcomborelonlydaysinteract$M.F.Ratio.event),
                        rel=mfcomborelonlydaysinteract$centrelpedmf, code = mfcomborelonlydaysinteract$coden, pg=mfcomborelonlydaysinteract$guardpestn,totfem=mfcomborelonlydaysinteract$nfemale,
                        sesh=standsessionn4(mfcomborelonlydaysinteract$sessionn),alt=mfcomborelonlydaysinteract$secondchoice,
                        male = mfcomborelonlydaysinteract$malen,
                        fem = mfcomborelonlydaysinteract$femn,codel= length(levels(as.factor(mfcomborelonlydaysinteract$coden))),
                        malel= length(levels(as.factor(mfcomborelonlydaysinteract$malen))),
                        feml= length(levels(as.factor(mfcomborelonlydaysinteract$femn))))



parametersintA <- c( "alpha",
                     "betafa", "betama", "betac", "betar", "betaga", "betapg","intafma", "intafapg", "intamapg", "intafmapg", "betanfem",
                     "epsO","epsF", "epsM"
)




sink("activity.PG.model.intfmapg.r.fixnfem")
cat("
model {
for (i in 1:n){
y[i] ~ dbern(p[i])
logit(p[i]) <- alpha 
+betanfem*totfem[i]
+betafa*fage[i]
+betama*mage[i]
+betapg*pg[i]
+intafma*fage[i]*mage[i]
+intamapg*mage[i]*pg[i]
+intafapg*fage[i]*pg[i]
+intafmapg*fage[i]*mage[i]*pg[i]
+betar*rel[i]
+epsF[fem[i]]
+epsM[male[i]]
+epsO[code[i]]
}
alpha~ dnorm(0, .001)
betanfem~ dnorm(0, .001)
betafa ~ dnorm(0, .001)
betama ~ dnorm(0, .001)
betapg ~ dnorm(0, .001)
intafma ~ dnorm(0, .001)
intafmapg~ dnorm(0, .001)
intafapg~ dnorm(0, .001)
intamapg~ dnorm(0, .001)
betar ~ dnorm(0, .001)

tau.oc <- 1 / (sd.oc*sd.oc)
sd.oc ~ dunif(0, 1)
tau.m <- 1 / (sd.m*sd.m)
sd.m ~ dunif(0, 1)
tau.f <- 1 / (sd.f*sd.f)
sd.f ~ dunif(0, 1)

for(i in 1:codel){
epsO[i]~ dnorm(0,tau.oc)}
for(i in 1:malel){
epsM[i]~ dnorm(0,tau.m)}
for(i in 1:feml){
epsF[i]~ dnorm(0,tau.f)}
}
")
sink()



actint.PG.model.intfmapg.intafac.intamac.r.nfem<-jagsUI ::jags(jags.data.A.int, initsA, parametersintA, "activity.PG.model.intfmapg.r.fixnfem", n.chains = nc, n.thin = nt, n.iter = ni, n.burnin = nb,parallel=TRUE,DIC=T)




#Constructing the data table

actint.PG.model.intfmapg.intafac.intamac.r.nfemsum<-MCMCsummary(actint.PG.model.intfmapg.intafac.intamac.r.nfem, round = 2)%>%rename(low = "2.5%", high = "97.5%")

names(ms1sum)
actint.PG.model.intfmapg.intafac.intamac.r.nfemsum.olap<-actint.PG.model.intfmapg.intafac.intamac.r.nfemsum%>%mutate(Effect = case_when(low > 0 & high> 0~ "+",
                                                                                                                                        low < 0 & high< 0~"-",
                                                                                                                                        TRUE ~"NotSignif"))



write.csv(actint.PG.model.intfmapg.intafac.intamac.r.nfemsum.olap, "Oactint.PG.model.intfmapg.intafac.intamac.r.nfemsum.olap.csv")#to make ghost name column a real column
Oactint.PG.model.intfmapg.intafac.intamac.r.nfemsum.olap<-read.csv("Oactint.PG.model.intfmapg.intafac.intamac.r.nfemsum.olap.csv")%>%filter( !grepl('eps', X))%>% mutate(X = gsub("\\[|\\]","",X))%>%#removing square brackets so can join to f output
  left_join(cbind(names(unlist(actint.PG.model.intfmapg.intafac.intamac.r.nfem$f)),as.data.frame(matrix(unlist(actint.PG.model.intfmapg.intafac.intamac.r.nfem$f ))))%>%rename("X"="names(unlist(actint.PG.model.intfmapg.intafac.intamac.r.nfem$f))", "f"="V1")%>%filter( !grepl('eps', X)),
            by=c("X"))#mcmc doesn't give f output so need to rejoin it

write.csv(Oactint.PG.model.intfmapg.intafac.intamac.r.nfemsum.olap, "table.Oactint.PG.model.intfmapg.intafac.intamac.r.nfemsum.olap.csv")

fit.table.actint.PG.model.intfmapg.intafac.intamac.r.nfem<-read.csv("table.Oactint.PG.model.intfmapg.intafac.intamac.r.nfemsum.olap.csv")



variancerand<-ggs(actint.PG.model.intfmapg.intafac.intamac.r.nfem$samples)%>%filter(grepl("eps", Parameter))%>%group_by(Parameter)%>%mutate(meanrand=mean(value))%>%ungroup()%>%select(-c("value", "Iteration", "Chain"))%>%distinct()%>%
  mutate(Paramgroup = case_when(grepl("epsF", Parameter)~"Female.id",grepl("epsM", Parameter)~"Male.id" ,grepl("epsO", Parameter)~"Oestrus.event" ))%>%group_by(Paramgroup)%>%mutate(vargroup=sd(meanrand))%>%ungroup()%>%
  select(Paramgroup,vargroup)%>%distinct()



ggactint.PG.model.intfmapg.intafac.intamac.r.nfem<-ggs(actint.PG.model.intfmapg.intafac.intamac.r.nfem$samples)%>%filter(!grepl("deviance", Parameter))%>%filter(!grepl("eps", Parameter),!grepl("alpha", Parameter))%>%mutate(Parameter=case_when(
  #Parameter=="betac" ~ "GroupSexRatio",
  Parameter=="betafa"~"FemaleAgeRank",
  Parameter=="betama"~"MaleAgeRank",
  Parameter=="betapg"~"State(Guard)",
  Parameter=="betar"~"GroupCenteredRelatedness",
  #Parameter=="intafac"~"FemaleAgeRank:GroupSexRatio",
  #Parameter=="intamac"~"MaleAgeRank:GroupSexRatio",
  Parameter=="intafma"~"FemaleAgeRank:MaleAgeRank",
  Parameter=="intamapg"~"MaleAgeRank:State(Guard)",
  Parameter=="intafapg"~"FemaleAgeRank:State(Guard)",
  Parameter=="intafmapg"~"FemaleAgeRank:MaleAgeRank:State(Guard)",
  Parameter=="betanfem"~"NumberOfAdultFemales"
))%>%arrange(desc(Parameter))

orderassort <- c( "GroupCenteredRelatedness",
                  "FemaleAgeRank",
                  "MaleAgeRank",
                  "FemaleAgeRank:MaleAgeRank",
                  "State(Guard)",
                  "MaleAgeRank:State(Guard)",
                  "FemaleAgeRank:State(Guard)",
                  "FemaleAgeRank:MaleAgeRank:State(Guard)",
                  #"GroupSexRatio",
                  #"FemaleAgeRank:GroupSexRatio",
                  #"MaleAgeRank:GroupSexRatio",
                  "NumberOfAdultFemales")


#significance and diagnostic plots
ggactint.PG.model.intfmapg.intafac.intamac.r.nfem$Parameter<-factor(ggactint.PG.model.intfmapg.intafac.intamac.r.nfem$Parameter, levels=orderassort)

catassort<-ggs_caterpillar(ggactint.PG.model.intfmapg.intafac.intamac.r.nfem%>%drop_na(Parameter)%>%filter(!grepl('deviance', Parameter)), line=0, sort=FALSE)+ theme_classic()+ xlim(-1,1)+
  labs(x="Posterior probability (HPD) to interact with a given female", y="")+scale_y_discrete(limits=rev)
catassort
ggs_density(ggactint.PG.model.intfmapg.intafac.intamac.r.nfem, hpd=TRUE)+xlim(-1,1)+ geom_vline(xintercept = 0)+theme_classic()+facet_wrap(~ Parameter, nrow = 4)+labs(y="Posteior samples")


ggs_compare_partial(ggactint.PG.model.intfmapg.intafac.intamac.r.nfem)#compares whole chain with the last value
ggs_autocorrelation(ggactint.PG.model.intfmapg.intafac.intamac.r.nfem)
ggs_traceplot(ggactint.PG.model.intfmapg.intafac.intamac.r.nfem)#traceplot of convergence
ggs_crosscorrelation(ggactint.PG.model.intfmapg.intafac.intamac.r.nfem)#check for highly correlated dependent variables (deep blue or red)






